# Start here

This folder is a working memory system for Codex: plain Markdown files it reads every session, so it remembers who you deal with, what was decided, and where everything is up to. Built for one person working inside a locked-down enterprise environment.

## The parts

- **Your Profile.** Who you are, how you work, how you sound, what stays private. Four pages, in your words.
- **Wiki.** One page per person, project, tool and insight, with a map at the front. Person pages carry a weight you set for how much their word moves you.
- **Working Files.** Documents you want it to read. Status lives on the Wiki page, not here.
- **Drop Zone.** The tray. Anything goes in; it files it and empties the tray.
- **Handover.** The note each session leaves for the next.
- **Logbook.** What it did, one file per month, so trust never rests on memory.
- **Rules.** `AGENTS.md`, which it reads every session, plus a shelf for the detail. Corrections you say out loud become rules on the spot.
- **Skills.** The jobs it knows how to do, by name: ingest, lint, discover and enrich for the memory itself; decision-check, ruling-docket, insight-extraction and write-it-up for the work; plus the rituals, who-is, draft-a-message, and the rule capture.
- **Routines.** Three of the skills on a schedule, if you want them there.

## Set-up

1. Unzip into your OneDrive. Do not rename the folders inside it afterwards.
2. Right-click the folder in File Explorer and choose **Always keep on this device**, so Codex can read every file.
3. If you already have notes on how you work or who matters, put them in `03-working-files/`. Rougher things (a voice transcript, a pasted Teams thread) go in `00-drop-zone/drops/`. The onboarding reads all of it before asking you anything.
4. Open Codex in the folder (VS Code with the Codex extension, the Codex app, or the CLI with this folder as the working directory). It reads `AGENTS.md` on its own.
5. Say **"read AGENTS.md and run the onboarding"**. About forty minutes, one question at a time. Turn dictation on (Windows key + H) and talk; long answers are the good kind.

## The three rituals

| You say | What happens |
|---|---|
| **"Start the day"** | Reads the Handover, the calendar if Codex can see one, and what is waiting on you. A short brief. |
| **"End of day"** | The half-hour where you talk and it files: what happened, who you spoke to, what was decided, what is bugging you. Writes tomorrow's Handover. |
| **"Lint"** | Weekly. Checks the health of the memory, fixes what is clear, asks at most two questions. |

Any skill can run on a schedule; these three are the usual set. The onboarding walks you through setting that up; the recipes and the one caveat are in `_engine-room/routines.md`.

## Model choice

Sol at medium effort for the daily rituals, high for a big filing session or a hard question across many pages, Terra for grunt work. Extra-high and ultra burn the token limit and take too long for this kind of work.

## What to expect

Week one: the profile exists, ten or so people pages exist with the weights you gave them, the debrief takes twenty minutes. Week two: the debrief gets shorter and it starts telling you things back. Month one: the weekly lint proposes pages for things you keep mentioning.

It will not send anything. It drafts, you send. And it will not know anything you did not tell it, drop in, or connect.

This folder is only as private as the machine and account it sits in. Anything your organisation would not want written outside its own systems should not go in here; the boundaries page is where you tell the agent the line.

Feedback is appreciated: what worked, what felt wrong, what you stopped using.

---

Built by Dan Robson, Robson Studio (https://robson.studio). This is a cut of the system I run my own work on. Feedback and the latest version: the page you downloaded it from.
