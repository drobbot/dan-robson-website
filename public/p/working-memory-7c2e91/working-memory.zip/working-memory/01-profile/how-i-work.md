---
title: How I work
status: not-yet-written
updated:
sources: []
---

# How I work

*How {{OWNER_NAME}} likes to operate and be helped. Filled during onboarding; refined every time a correction lands. If you already have a written version of this, it goes in `03-working-files/` and the onboarding reads it first.*

## How I make decisions

(What you need in front of you before you decide. Who you check with. What a good decision process looked like in a week that went well.)

## How I want to be helped

(Short answer or short answer plus reasoning. Told or asked. Morning brief: blunt or with the reasoning. What to hold until later versus what to interrupt with.)

## My working rhythm

(Deep-work hours, meeting-heavy days, when the debrief happens.)

## How I judge input from other people

(The frame behind the weights on people pages: whose word moves you, whose needs corroboration, and what to do when two people you weigh the same disagree.)
