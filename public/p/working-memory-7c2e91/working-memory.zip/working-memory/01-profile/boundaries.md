---
title: Boundaries
status: not-yet-written
updated:
sources: []
---

# Boundaries

*Privacy only. Three drawers. Started at onboarding; filled properly in the private conversation (say "just us"). These lines bind every session and every draft.*

## Drawer one: never goes in this folder

- Credentials of any kind. If one lands in the Drop Zone, the agent says it happened and does not file it.
- (Anything the organisation this machine belongs to would not want written outside its own systems. {{OWNER_NAME}} names the line.)

## Drawer two: in the folder, but never in a draft, message, or brief that another person sees

- (Assessments of individuals. Anything told in confidence. Whatever else {{OWNER_NAME}} names.)

## Drawer three: ask first

- Until the private conversation has happened, anything about money, individuals' performance, or family: the agent asks before using it.
- (The grey areas, named by {{OWNER_NAME}}.)
