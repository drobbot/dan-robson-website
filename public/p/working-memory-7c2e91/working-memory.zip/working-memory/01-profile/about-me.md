---
title: About me
status: not-yet-written
updated:
sources: []
---

# About me

*First draft written during onboarding. {{OWNER_NAME}} can open and change this any time; it is a page, not a setting. Lines the agent worked out rather than heard are marked `(inferred)`.*

## Who I am

(What you do, in your own words. How you got here. What you care about in the work.)

## What is on right now

(The live programs, the decisions in flight, this quarter's push, and the context behind them: why these, why now.)

## Facts the assistant genuinely needs

(Time zone, the fixed commitments that shape the week, the things it should never book over. Only what changes how it helps. Private life stays private per [boundaries](boundaries.md).)
