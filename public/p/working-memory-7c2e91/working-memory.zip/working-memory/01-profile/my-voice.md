---
title: My voice
status: not-yet-written
updated:
sources: []
---

# My voice

*How {{OWNER_NAME}} writes, so drafts sound like them. Built from real examples, never from a description; onboarding asks for three ordinary sent messages. A voice correction is a rule and gets captured on the spot. The draft-a-message skill reads this page every time.*

## Samples

(Paste two or three real messages here, labelled by register: to a direct report, to a peer, upward.)

## How I sound

(What the samples show: length, formality, greetings and sign-offs, the words you reach for.)

## Never

(Words and phrases that are not you. Anything that would make a colleague think someone else wrote it.)
