Start at [AGENTS.md](AGENTS.md). It is the front door for any agent working in this folder; this file exists only so other tools find it.
