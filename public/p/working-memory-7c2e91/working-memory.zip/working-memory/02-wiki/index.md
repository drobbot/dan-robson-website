# The Wiki map

*Every Wiki page, findable from here. The agent adds a line when a page is created and only ever adds to this file. Profile, Rules, Handover and Logbook are not Wiki pages and do not appear here.*

## Sections

- [people](people/README.md): one page per person, with the weight {{OWNER_NAME}} gives their word
- [projects](projects/README.md): one page per program, initiative, or piece of work. Answers "where is this up to?"
- [tools](tools/README.md): how the connected tools are read. The one pre-filled section
- [decisions](decisions/decision-log.md): one line per decision, newest first, pointing at the page that holds the detail
- [insights](insights/README.md): patterns noticed across everything

## Pages

### people

- [example-jane-bushby](people/example-jane-bushby.md): a filled example, invented person. Delete once real pages exist

### projects

- (none yet)

### tools

- [email](tools/email.md)
- [calendar](tools/calendar.md)
- [teams](tools/teams.md)

### insights

- [discover-watch](insights/discover-watch.md): tentative connections waiting for evidence
