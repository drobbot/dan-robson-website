# People

One page per person {{OWNER_NAME}} deals with: what they have said, what is outstanding between us, and how much their word weighs. Pages accumulate from the debriefs and the drops; onboarding seeds the ten or so people who matter most.

**One person, one page.** Names drift across dictation and transcripts (Stef, Steph, Stephanie). Check [the alias table](../../_engine-room/aliases.md) before creating a page, and add every new spelling there rather than making a second page.

Use [the template](_template.md); [example-jane-bushby](example-jane-bushby.md) shows a filled one. The field that matters: `weight: high | medium | low`, set by {{OWNER_NAME}}, never inferred. It decides the default reading when two people's inputs collide.
