---
title: Full Name
aliases: [first name, nickname, initials]
relationship: peer
weight: medium
updated: YYYY-MM-DD
sources:
  - 04-sources/ingested/YYYY-MM-DD-slug.md
---

# Full Name

## Role and context

(Who they are, where they sit, what they own. One paragraph.)

## How we work together

(Frequency, channel, what they need from {{OWNER_NAME}}, what {{OWNER_NAME}} needs from them.)

## What they have said that still matters

(Standing positions, steers, lines that frame things. Dated, cited. Not a transcript.)

## Open between us

- (What {{OWNER_NAME}} owes them, what they owe {{OWNER_NAME}}, with the date it last moved.)

## Interactions

- YYYY-MM-DD: (one line per interaction that changed something; newest at the bottom)
