---
title: Jane Bushby (example)
aliases: [Jane, JB]
relationship: peer
weight: high
updated: 2026-09-08
sources:
  - 04-sources/ingested/2026-09-08-example-end-of-day.md
---

# Jane Bushby (example)

*An invented person, filled in so the shape is visible. Delete this page once real pages exist.*

## Role and context

Change lead on the program. Owns the rollout plan and the user communications. Sits between the program board and the site teams, so she hears both sides first.

## How we work together

Weekly one-to-one, Thursday. Prefers a short message on Teams to an email. Needs decisions from me before Wednesday to land them in the Friday update. I need her read on how the sites are taking things, which she gives plainly if asked directly.

## What they have said that still matters

- 2026-09-08: "The sites will accept a slower rollout, but not a moving target." Her line on scope; cited in the program page. `(source: 2026-09-08 debrief)`
- 2026-09-08: Thinks the second site should go before the first `(inferred from her question about readiness, not stated)`.

## Open between us

- I owe her the decision on the rollout order, by Wednesday 2026-09-10.
- She owes me the site readiness summary, promised 2026-09-08, no date given.

## Interactions

- 2026-09-08: corridor conversation after the board; the two lines above.
