# Projects

One page per program, initiative, or piece of work {{OWNER_NAME}} is carrying. The page answers "where is this up to?", including what has been decided and who is waiting on whom. Decisions live on the page they are about; the [decision log](../decisions/decision-log.md) is one line each pointing back here.

Onboarding relabels this section in the Wiki map to the noun {{OWNER_NAME}} uses (programs, workstreams, matters). The folder name stays.

Page shape: frontmatter (`title`, `status: active | paused | done`, `updated`, `sources`, `people` as a list of links), then **Where it is up to** · **What has been decided** · **Waiting on** (name and date) · **Next**.
