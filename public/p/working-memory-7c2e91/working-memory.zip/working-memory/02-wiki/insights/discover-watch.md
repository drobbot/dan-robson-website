# Discover watch

Tentative connections the discover skill noticed but could not yet quote from both sides. Re-checked each run; promoted to a link and a callout when the evidence is there, or dropped after three runs without it.

| Date noticed | Pages | The mechanism, in one line | Status |
|---|---|---|---|
| | | | |
