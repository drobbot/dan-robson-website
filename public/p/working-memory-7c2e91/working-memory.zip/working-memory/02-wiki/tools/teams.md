# Teams

*Connected: (not yet recorded; onboarding fills this in). If not connected, a pasted thread in the Drop Zone does the same job.*

- **A chat thread is one source, however many messages it holds.** Synthesise what was decided, asked, and left open; never paste the thread into a page.
- **Attribution doubt is flagged, not guessed.** If it is unclear who said what, say so on the page.
- **Meeting transcripts and recaps merge with the debrief** into one account of the meeting, never three versions.
- **Read-only.** Nothing posted, nothing reacted to. A reply is a draft in the chat with {{OWNER_NAME}}, per [my voice](../../01-profile/my-voice.md).
