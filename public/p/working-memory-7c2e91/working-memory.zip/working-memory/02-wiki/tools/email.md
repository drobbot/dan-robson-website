# Email

*Connected: (not yet recorded; onboarding fills this in). If not connected, forwarded or pasted emails go in the Drop Zone and these rules still apply.*

- **The thread is the unit, not the message.** Record what was agreed, what was asked, and what is still outstanding.
- **Where things land:** facts go to the Wiki page of the person or project the thread is about; anything needing {{OWNER_NAME}}'s action goes to the morning brief, not buried in a page.
- **Drafts sound like the owner.** Any reply is drafted against [my voice](../../01-profile/my-voice.md) and waits. Nothing sends.
- **Redact anything credential-shaped** before it reaches a page.
