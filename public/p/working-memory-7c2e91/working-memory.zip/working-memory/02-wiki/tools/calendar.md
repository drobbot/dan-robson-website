# Calendar

*Connected: (not yet recorded; onboarding fills this in). If not connected, a pasted day or week in the Drop Zone does the same job.*

- **The calendar anchors the morning brief.** For each person on today's meetings, the brief pulls what is open between {{OWNER_NAME}} and them and the last thing they said that still matters.
- **Never writes.** No events created, moved, or accepted. A suggested time is a line in the brief.
- **Recurring meetings are context, not news.** Mention one only when something about it changed.
