# Tools

How the connected tools are read. Deliberately generic lessons, written about the category rather than one product, so they survive app updates. They ship whether or not the connector is switched on, so turning one on later is one conversation. Onboarding records which connectors Codex on this machine can reach at the top of each page.

- [email](email.md)
- [calendar](calendar.md)
- [teams](teams.md)

One rule across all three: **read-only, always.** Nothing sends, nothing is created or moved in the source tool, and anything credential-shaped is never copied into a page.
