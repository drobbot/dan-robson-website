---
title: Decision log
updated:
---

# Decision log

One line per decision: date · the decision · who made it and where it is recorded. Newest first. The detail lives on the project or person page cited. The end-of-day debrief appends here whenever a decision surfaces.

| Date | Decision | Source |
|---|---|---|
| | | |
