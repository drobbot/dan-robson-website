One file per open question, `q-<slug>.md`. The "start the day" brief lists what is open. Answer by telling the agent.
