# Drop Zone

- `drops/` is the tray. Drop anything in: a dictated note, a pasted Teams thread, an email export, a photo of a whiteboard, a half-thought. The agent reads it, files it where it belongs, moves the original to `04-sources/originals/`, and the tray is empty again.
- `questions/` is where the agent parks what it cannot decide alone. One file per question, `q-<slug>.md`, with `status: open | answered` and `created:` in the frontmatter, then the question in one line and what happens on each answer. Answer by telling the agent, not by editing the file. Answered questions stay; that is the lineage.
