Drop anything here. Filed and emptied at the next "end of day" or "start the day". A date at the front of the filename (`2026-09-08-corridor-chat-jane.md`) helps, but nothing depends on it.
