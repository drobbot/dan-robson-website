# Working Files

Documents {{OWNER_NAME}} wants the agent to be able to read: the way-I-work notes already written, a stakeholder map, a plan on a page. The onboarding reads them before asking anything. Files live here; status lives on the Wiki page. Nothing the organisation would not want outside its own systems (see [boundaries](../01-profile/boundaries.md)).
