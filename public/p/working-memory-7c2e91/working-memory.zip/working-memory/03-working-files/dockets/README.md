Ruling dockets, one per sitting, `YYYY-MM-DD-docket.md`. Written by the ruling-docket skill.
