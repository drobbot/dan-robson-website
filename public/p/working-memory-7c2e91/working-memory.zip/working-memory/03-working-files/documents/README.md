Documents the write-it-up skill produced, `YYYY-MM-DD-<slug>.md`. Standalone; the project page points here.
