---
name: draft-a-message
description: Draft an email, Teams message, or note to a named person in the owner's voice. Use when the owner says "draft a message to X", "reply to X", "write back to Jane", or asks for help wording something to someone. Reads my-voice.md and the person's page every time. Never sends; never posts; hands back text in the chat.
---

# Draft a message

**The job:** a first draft that sounds like {{OWNER_NAME}}, to the right person, saying what they asked, and nothing from the private page.

## Steps

1. Resolve the recipient through `_engine-room/aliases.md`. Unknown name: ask, do not guess.
2. Read `01-profile/my-voice.md` (samples, how I sound, the Never list) and the recipient's page (**Open between us**, last interactions, `relationship:`).
3. Read `01-profile/boundaries.md`. Nothing from drawer two goes in. Anything in drawer three: ask first.
4. Draft in the register the samples show for that relationship. Match length to what {{OWNER_NAME}} would send; a Teams reply is two lines, not an essay.
5. Hand it back in the chat as plain text. Say in one line what it draws on ("uses the rollout-order decision from Tuesday").
6. If {{OWNER_NAME}} corrects the voice, capture it per never-and-always into `my-voice.md`.
7. Log it.

## Never

- Never sends, posts, or creates a draft inside the email or Teams client. The text lives in the chat until {{OWNER_NAME}} moves it.
- Never uses a word on the Never list.
- Never states an inference about the recipient as fact.
