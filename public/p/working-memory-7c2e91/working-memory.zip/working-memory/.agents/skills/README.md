# Skills

A skill is a written-down way of doing a repeatable job so it runs the same way every time. Each lives at `.agents/skills/<name>/SKILL.md`, where Codex looks; invoke one by name in a chat (`$lint` in the CLI or IDE, `@lint` in ChatGPT) or just say the words. Any skill can be put on a schedule; [routines.md](../../_engine-room/routines.md) has the recipes for the usual three.

| Skill | In one sentence |
|---|---|
| [onboarding](onboarding/SKILL.md) | The first session. Reads what {{OWNER_NAME}} already has, then one conversation that writes the profile, seeds the people, sets the rules |
| [the-private-conversation](the-private-conversation/SKILL.md) | A second, shorter session that fills in the boundaries page. Say "just us" |
| [start-the-day](start-the-day/SKILL.md) | Read the Handover, the calendar if connected, and what is waiting. A one-screen brief |
| [end-of-day](end-of-day/SKILL.md) | The half-hour debrief that captures the day that is not in any system, and files it |
| [ingest](ingest/SKILL.md) | File everything new: the Drop Zone and any connected email, Teams or calendar, vetted, noted, linked |
| [lint](lint/SKILL.md) | The health check: orphans, dead links, the map, stale pages, duplicates, frontmatter, sizes. Fixes what is clear |
| [discover](discover/SKILL.md) | From new notes outward, find the mechanism the Wiki already holds in other words, and link them. Three a run |
| [enrich](enrich/SKILL.md) | Fill thin hub pages from the notes that cite them; add the missing links; propose profile updates. Never rewrites |
| [decision-check](decision-check/SKILL.md) | Five questions on one decision before it is committed: the incentive, the fast choice, the trade, reversibility, what it optimises for. Never decides |
| [ruling-docket](ruling-docket/SKILL.md) | Every decision waiting on {{OWNER_NAME}}, in one document: question, options with trade-offs, a recommendation, what else is theirs to call |
| [insight-extraction](insight-extraction/SKILL.md) | Mine a pile of notes or documents for the findings that would change a decision, ranked and sourced. Not a summary |
| [write-it-up](write-it-up/SKILL.md) | Turn what the memory knows about a topic into a standalone document for a named reader, in {{OWNER_NAME}}'s voice |
| [never-and-always](never-and-always/SKILL.md) | When {{OWNER_NAME}} says "never do that" or "always do this", write it down straight away |
| [who-is](who-is/SKILL.md) | Answer "who is X, where are we with them" from the person page, with said, reported, and inferred kept apart |
| [draft-a-message](draft-a-message/SKILL.md) | Draft a message to a named person in {{OWNER_NAME}}'s voice, respecting the boundaries page. Never sends |

Every skill run starts by loading [execution-discipline](execution-discipline/SKILL.md): ground truth only, stop loudly, done means evidence, err toward exclusion.

Two rules every skill follows: nothing leaves this machine without {{OWNER_NAME}}'s yes, and every run writes a Logbook entry, a line per step, `done` or `skipped: reason`. A step that failed is a Logbook line and a line in the next brief, never a silent skip.

---

Built by Dan Robson, Robson Studio. https://robson.studio
