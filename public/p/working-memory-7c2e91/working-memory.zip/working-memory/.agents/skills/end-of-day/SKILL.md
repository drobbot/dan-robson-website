---
name: end-of-day
description: The daily debrief. Use when the owner says "end of day", "debrief", or "wrap up the day", or when a scheduled task opens it at the end of the working day. Captures the day that is not in any system, files it, writes the Handover. Needs the owner present; if they are not, file the drops and stop.
---

# End of day

**The job:** the half-hour where {{OWNER_NAME}} talks and the agent captures the day that does not exist in any system, then files it so tomorrow starts already knowing.

Email and Teams can be read through a connector or dropped in the tray. What was said in a corridor, what {{OWNER_NAME}} thinks about it, and what they decided exists nowhere unless it is said out loud once a day. That is the input nothing else replaces.

**Rules.** One question at a time. Long rambling answers are the good kind; say so on the first run. Let a tangent run. Read back as sentences. Capture never/always on the spot. Twenty to thirty minutes; past forty, stop and file what exists.

## Opened by a scheduled task

Run the ingest skill, then post one line and stop: *"Ready for the end-of-day debrief when you are. Say go."* Wait. If no reply comes, write the Logbook line `end of day: opened, owner not present, drops filed` and do nothing else. Never run the questions against an empty chair; never write a Handover from nothing.

## Before the first question

1. Read the Handover and today's brief, if there was one.
2. Run the ingest skill: the Drop Zone, and today's email, Teams and calendar if connected. Say what you filed, one line each.

## The questions

Skip any the filing already answered, and say so.

1. *"What happened today that isn't written down anywhere?"* Let it run.
2. *"Who did you talk to, and what came out of it?"* Each person: a dated line under **Interactions**, **Open between us** updated if something is now owed. New person: new page from the template, `weight:` marked `(to confirm)`, name added to `aliases.md`.
3. *"Did anything get decided today?"* A line in the decision log and a dated line on the project page. A contradiction with an earlier decision is recorded, not overwritten.
4. *"Anything move on the things that are on?"* Update **Where it is up to** on the project pages.
5. *"What's bugging you?"* Files to the project or person page, marked as {{OWNER_NAME}}'s view, dated. Third time this month: a candidate for `insights/`, say so.
6. *"What did you promise anyone, and what is anyone waiting on from you?"* **Open between us**, with dates.
7. *"What's tomorrow?"* The Handover's **Tomorrow** section. Pre-read the pages of the people on it.
8. *"Anything you want me to stop or start doing?"* Captured Rules, in the same breath.

## Then

- Read back the three most important things as sentences. *"What did I get wrong?"*
- Ask at most two questions that came up while filing. The rest become question files.

## After they leave

1. Write the note `04-sources/ingested/YYYY-MM-DD-end-of-day.md`, with **What changed where**.
2. Update the Wiki map for any page created.
3. Copy the outgoing `_engine-room/handover/handover.md` to `archive/YYYY-MM-DD.md`, then write the new one: **Where things stand** · **Tomorrow** · **Waiting on** · **Open questions** · **Verify before trusting** (anything inferred).
4. Log it, a line per step.

## Never

- Never drafts a message unless asked; note "draft the note to X" under **Tomorrow** instead.
- Never resolves a conflict between two people. Records it, asks.
- Never invents a date. "Soon" is not a date.
