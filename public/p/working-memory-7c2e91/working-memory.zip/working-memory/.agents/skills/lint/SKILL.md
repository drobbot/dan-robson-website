---
name: lint
description: The health check on the working memory. Use when the owner says "lint", "weekly lint", or "health check", or when a scheduled task runs it. Finds orphan pages, dead links, stale pages, duplicates, missing frontmatter, oversized files and old questions. Fixes what is unambiguous and logs every fix; anything interpretive becomes at most two questions. Never deletes. Can run unattended.
---

# Lint

**The job:** find what has drifted, fix what is clear, ask about the rest. Weekly is the usual cadence.

**Fix first, ask by exception.** A check that only reports files the same problem forever.

## The checks

1. **Orphans.** Wiki pages no other page links to. Link each from the page it obviously belongs with (a person from their project, a project from the people on it). If nothing relates, list it.
2. **Dead links.** Every relative link under `02-wiki/` and `01-profile/` resolves to a file. Repair a renamed target; remove a link to a page that never existed; log each.
3. **The Wiki map.** Every page under `02-wiki/` has a line in `02-wiki/index.md`; every line points at a file; the page count on disk matches the map. Append what is missing.
4. **Stale pages.** A project with `status: active` untouched for 30 days, or a person page untouched for 60, gets one line in the report: "done, dead, or just quiet?" Never demote on your own judgement; check first whether the name appears in notes from the last 30 days, and say so.
5. **Duplicates.** Two pages that look like the same person or thing, or a name in `aliases.md` with no page, or a page with no alias row. Propose the merge; merging waits for a yes. Add missing alias rows.
6. **Frontmatter.** Person and project pages carry `title`, `updated`, `sources`; person pages carry `weight`, `relationship`, `aliases`. Fix the mechanical ones (a missing `updated:` gets today's date and a `(lint)` mark); flag a missing `weight:` for {{OWNER_NAME}} to set.
7. **Sizes.** `AGENTS.md` under 700 words (move detail to `_engine-room/rules/` if not). This month's Logbook file exists. Captured Rules fits on a screen. No note in `04-sources/ingested/` is a pasted transcript.
8. **The Drop Zone.** Anything in `drops/` older than a day means ingest has not run: run it. Questions in `questions/` open for 14 days: list them once, then park.
9. **Captured Rules triage.** Any rule in `AGENTS.md` that has grown a paragraph moves to the Rules shelf with a pointer. Two rules that contradict: show both, ask which stands.
10. **Feedback nudge, once.** If the oldest Logbook entry is 21 days or more old and no file matching `*-feedback.md` exists in `03-working-files/documents/`, add one line to the report: "Three weeks in. If you want to send feedback on the system, the page you downloaded it from has a prompt that writes it for you." Say it once, and once more a week later if still nothing; then never.

## The output

A short report: what was fixed (with counts), what looks stale, and at most two questions. A Logbook entry with a line per check, `done` or `skipped: reason`, and the counts from check 3 and check 7. A finding raised twice without an answer is parked in the Logbook and stops being asked.

## Never

- Never deletes a page, a note, or a link that resolves. Superseded is the strongest action.
- Never rewrites content while fixing structure. Moving is not editing.

**Opened by a scheduled task:** run everything unattended, put questions in `00-drop-zone/questions/` as files and in the last message, mark the Logbook line `scheduled`.
