---
name: the-private-conversation
description: A second, shorter session that fills in the boundaries page properly so the play-it-safe rule can come off. Use when the owner says "just us" or "private conversation". Runs once, and again any time something belongs on the private page.
status: waiting
---

# The private conversation

**The job:** twenty minutes that fill in `01-profile/boundaries.md` properly, so the ask-first rule set at onboarding comes off and the agent runs on {{OWNER_NAME}}'s real lines.

Onboarding writes founding files, and founding files steer everything after. The questions that most need a considered answer are about people and confidentiality, and they go better in a session of their own. Same rules as onboarding: one question at a time, one probe then move, every answer written and read back. "I'd rather not say" is a real answer and gets written down as one.

## The opening

> Just us this time. Two topics: what stays out of this folder, and how you want me to handle what I learn about other people. Everything goes in a page you can read and change.

## Part one: the three drawers (about 10 minutes)

Open `01-profile/boundaries.md` and read its three drawer headings aloud; they are the taxonomy. **Sort before you ask:** name concrete things you already hold from onboarding and the first debriefs, one at a time, and let {{OWNER_NAME}} call a drawer for each. Then:

1. *"This machine and this OneDrive belong to your organisation. What is the line for what goes in here versus what stays in their systems?"* Drawer one, in their words.
2. *"Anyone I should be careful around? Someone whose page should never feed a draft, someone who should never be copied in?"* Drawer two unless told otherwise.
3. *"Anything where you'd want me to check with you every time before using it?"* Drawer three.

## Part two: people and judgement (about 7 minutes)

4. *"When I write what someone said, do you want my read on why they said it, or just what they said?"* Sets whether `(inferred)` lines go on people pages at all.
5. *"If two people you weigh the same tell me different things, what do you want me to do?"* Into `how-i-work.md` under **How I judge input from other people**.
6. *"Anything about money, contracts, or performance that should stay off pages entirely?"*

## The close

1. Read the whole boundaries page back. *"What's wrong, and what's missing?"*
2. Remove the standing ask-first line in drawer three; replace it with {{OWNER_NAME}}'s own lines, dated.
3. Say: *"From now on these lines run everything I do. Change any line any time. Say 'just us' again whenever something belongs here."*
4. Set this file's `status:` to `done`. Log it. Update the Handover.
