---
name: start-the-day
description: The morning brief. Use when the owner says "start the day", "morning", or "brief me", or when a scheduled task runs it. Reads the Handover, open questions, and the calendar if Codex can see one, preps the people on it, and gives a one-screen brief. Not for filing large drops; that is end-of-day's job.
---

# Start the day

**The job:** read everything waiting, prep the people on today's calendar, and give {{OWNER_NAME}} a brief they can read in under two minutes.

## Steps

1. **Read** `_engine-room/handover/handover.md`, the open questions in `00-drop-zone/questions/`, and anything new in `00-drop-zone/drops/`. Run the ingest skill first if there is anything to file.
2. **Verify the Handover.** Anything it asserts that is cheap to check against the pages, check. Say what you could not verify.
3. **Today's people.** Read the calendar through the connector if Codex has one (see `02-wiki/tools/calendar.md`), otherwise from a calendar dropped in the tray; if neither, say "no calendar today" and skip. For each person: what is open between {{OWNER_NAME}} and them, and the last thing they said that still matters. No page: say so, offer to create one after the meeting.
4. **If email or Teams is connected**, skim since the last brief for anything owed to {{OWNER_NAME}} or by them. Read-only.
5. **Write the brief**, each section only if it has content: **Carried over** (three lines at most) · **Today's people** (one line each) · **Waiting on you** (oldest first) · **Questions I have** (at most two) · **Proof of life** (one line: what was filed, the tray is empty).
6. **Log it.** Do not rewrite the Handover; it stands until end of day.

## Rules

- The whole brief fits on one screen. A brief that recites everything trains people to stop reading it.
- Ask a question once. Unanswered, it moves to the Drop Zone and stops appearing here.
- While the private conversation is still `waiting`: mention it once on the first day after onboarding, once a week later, then never.
- **Opened by a scheduled task:** do everything above without waiting for input, leave the brief as the last message, mark the Logbook line `scheduled`.
