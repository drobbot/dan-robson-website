---
name: who-is
description: Answer "who is X", "where are we with X", "what has X said about Y", or "prep me for my meeting with X" from the person page and cited sources, keeping what they said, what the owner said about them, and what the agent inferred apart. Use for any question about a named person.
---

# Who is

**The job:** answer a question about a person from their page and the notes it cites, with said, reported, and inferred kept apart.

## Steps

1. Resolve the name through `_engine-room/aliases.md`. Not there: say so and ask whether it is a new person or a spelling of an existing one.
2. Read the person page. If the question is about a topic or a meeting, also read the project page and the last two end-of-day notes for anything {{OWNER_NAME}} said they wanted from this person.
3. Answer in this shape, short: **Who they are** (role, relationship, weight) · **Where things stand** (open between us, with dates) · **What they have said that bears on this** (dated, cited) · **My read** (only if `how-i-work.md` allows inferred lines; marked).
4. If the page is thin, say so. Never pad.
5. Fix anything the answer surfaced (a missing link, a stale line), and log the run.

## Never

- Never quotes without naming the note it came from.
- Nothing from drawer two of the boundaries page goes into an answer that could be shared. If the ask is "help me write to X", hand over to draft-a-message.
- Weight is shown, not applied: say "high weight" next to a name; do not soften what a low-weight person said.
