---
name: never-and-always
description: Capture a rule the moment the owner says "never do that" or "always do this" about how the agent works, in any session. Always on. Not for one-off instructions about today.
---

# Never and always

**The job:** when {{OWNER_NAME}} says "never" or "always" about how you work, write it down straight away, so it never has to be said twice.

## Steps

1. **Notice it.** It counts if it would still be true next month. "Never put my read on someone into a draft" is a rule; "don't send that one today" is an instruction. It counts inside a corrected draft or a "no, not like that". When you can't tell, write it down and say so.
2. **Write it now**, in their words, one line, dated.
3. **One rule, one home.** About how they sound: `01-profile/my-voice.md`. About what stays private: `01-profile/boundaries.md`. Everything else: Captured Rules in `AGENTS.md`. Whichever home, Captured Rules gets a dated line saying what was captured and where.
4. **Say it back** in one line.
5. **Check it doesn't fight an older rule.** If it does, show both and ask which stands.
6. **Keep the front door short.** When Captured Rules grows past a screen, move detail to `_engine-room/rules/` and leave a pointer.
7. **Log it**: one Logbook line, "rule captured: …".

## Never

- Never writes a rule {{OWNER_NAME}} did not say. An inference from behaviour is a suggestion for the weekly lint.
- Never deletes an existing rule without showing them first.
- Never waits until the end of the session.
