---
name: discover
description: Find non-obvious connections between new material and what the working memory already holds. Use when the owner says "discover", "what connects", or "any patterns". Weekly is a good cadence; it can also run on a schedule. Starts from notes written since the last run, extracts the mechanism behind each, searches the Wiki for the same mechanism in different words, and links the pages with a dated note. Capped at three connections a run. Never starts from existing insights and looks for confirmation.
---

# Discover

**The job:** find the pattern that recurs across notes but has not been linked yet.

**Direction matters.** Start from what is new and search the Wiki for what it echoes. Never start from `02-wiki/insights/` and look for evidence; that is confirmation bias.

## Steps

1. **Orient.** Read the Logbook back to the last `discover` line. Read `02-wiki/insights/discover-watch.md` for tentative connections from earlier runs that may now be ready.
2. **New material.** Every note in `04-sources/ingested/` and every person or project page created or substantially updated since the last run. Up to eight items a run; the rest wait.
3. **The mechanism, not the topic.** For each item, write two sentences on the underlying pattern or tension. "This is about the board" is the topic. "This is about a decision that keeps being deferred because nobody owns the consequence of getting it wrong" is the mechanism. Pull three or four search phrases from the mechanism, not from the subject.
4. **Search.** Grep `02-wiki/` and `04-sources/ingested/` for those phrases and close variants. Read every candidate far enough to tell a genuine parallel (same dynamic, different subject) from a superficial one (same words, different thing). Two pages naming the same person is not a parallel.
5. **Rate it.** `strong`, `moderate`, or `tentative`. To call one strong or moderate you must be able to quote both pages. If you cannot, it is tentative.
6. **Apply, capped at three.** For each strong or moderate parallel: a link both ways, and a dated two-line callout on each page under a `## Connections` heading saying what the shared mechanism is and where else it shows up. Tentative ones go to `02-wiki/insights/discover-watch.md` with the date, and get re-checked next run. Finding more than three means the bar slipped; demote the weakest.
7. **Insight check.** If the same mechanism now shows up on three or more pages, draft one page in `02-wiki/insights/`, cited to all of them, and offer it in the report. {{OWNER_NAME}} decides whether it stays.
8. **Report and log.** Three lines at most: what was linked, what is on watch, what was offered. Logbook entry with counts. Most runs find nothing; say so in one line.

## Never

- Never writes a callout without the quotes behind it.
- Never links because two pages share a name, a project, or a buzzword.
- Never rewrites a page while linking it.
