---
name: insight-extraction
description: Mine a pile of material for the findings that would change a decision. Use when the owner says "what stands out in these", "what's interesting here", "pull the insights", or points at a set of notes, transcripts, or documents and asks what matters. Returns a short ranked list, each item sourced and confidence-capped by what backs it. Not a summary.
---

# Insight extraction

**The job:** turn a pile (a week of notes, a set of meeting transcripts, a folder of documents) into a short, ranked, sourced list of the things that would change a decision.

**An insight is a claim that would change a decision.** "Jane prefers Teams to email" is an observation. "The sites will accept a slower rollout but not a moving target" is an insight; it changes how scope gets communicated.

## What counts

| Criterion | What it means |
|---|---|
| **Convergent** | The same finding appears across independent sources |
| **Emergent** | Only visible when several things are held together; no single source states it |
| **Surprising** | Overturns the obvious, the folklore, or a prior assumption |
| **Tension** | Two credible sources disagree, and the resolution is the insight |
| **Decision-relevant** | It would change what gets done, prioritised, or dropped |

Rank by novelty, decision relevance, and evidence strength together. Drop what is true but obvious, or interesting but unactionable.

## The pass

1. **Scope it.** Name the corpus out loud: which notes, which folder, what dates. If genuinely ambiguous, ask once.
2. **Read the distilled layer first**: the notes in `04-sources/ingested/`, the person and project pages. Drill into originals only for candidates that make the shortlist.
3. **Extract candidates**, each in the source's own words, with where it came from.
4. **Score and rank.** Keep the top three to seven. Three strong beats seven padded.
5. **Dedupe against what the Wiki already holds.** A pattern already on a page or in `02-wiki/insights/` is a re-confirmation: say so and strengthen that entry rather than opening a second.
6. **Confidence, capped by evidence.** `forming` (one source), `firming` (two or three), `firm` (consistent across sources, or the person with the weight to settle it said it). One transcript never makes an insight firm. Weight the source: the person who owns the outcome beats the person who heard about it.
7. **Write it up** and hand back.

## The shape

```
INSIGHT     the claim, one plain sentence
WHY         which criteria it hits
EVIDENCE    who and what backs it, with dates
CONFIDENCE  forming | firming | firm
SO WHAT     the decision it would change
```

Firm insights go to `02-wiki/insights/` as a page, cited to every source; forming and firming ones go to the discover watch list. Log the run.

## Never

- Never promotes an insight to a page on one source.
- Never lets an inferred line on a person page count as evidence.
- Never summarises. If nothing would change a decision, say so in one line.
