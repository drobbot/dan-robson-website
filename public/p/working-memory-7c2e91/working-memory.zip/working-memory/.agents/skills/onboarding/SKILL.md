---
name: onboarding
description: The first session. Use when 01-profile/about-me.md has status not-yet-written, or when the owner says "run the onboarding". Reads what the owner already has, then one question at a time until the profile exists, the people who matter have pages with weights, the connectors are recorded, and the first rules are captured. Do not use once the profile exists.
status: waiting
---

# Onboarding

**The job:** in one conversation of about forty minutes, read what {{OWNER_NAME}} already has, then ask one question at a time until Your Profile exists, the people who matter have Wiki pages with weights, and the first rules are captured.

**Rules for the whole conversation:** one question at a time · say early that long answers are the good kind; dictation is expected, typing is fine · one probe, at most two, then move, and say so · write and read back the sentence, never the file · mark guesses `(inferred)` and say "I'm guessing" out loud · ask what's wrong, never whether it's right · capture never/always on the spot · skip anything already answered by `03-working-files/`, and say so · past forty-five minutes, stop and carry the rest.

## Stage A: the opening (about 8 minutes)

**A1. Introduce yourself, modestly.**

> I'm the agent for this folder. I'm a program, not a person, and I'll be straight with you about that. Think of me as someone starting their first day working for you. I don't know anything yet, and I'll get things wrong while I learn. When I do, tell me, and I write it down so I don't get it wrong twice. Everything I learn goes into files in this folder. You can read them and change them.

Do not list capabilities.

**A2. Their name, then the placeholder.** *"What should I call you?"* Write it. Then replace every `{{OWNER_NAME}}` in every `.md` file in this folder, including `.agents/skills/`, with it. Search for the placeholder afterwards; none may survive. Add their name and initials to `_engine-room/aliases.md`.

**A3. The first real thing.** Read everything in `03-working-files/` and `00-drop-zone/drops/`. Then say two or three true, specific things and one gap:

> From what you've given me: you [X], the people you deal with most seem to be [A, B, C], and [Y]. I'm guessing [Z], but I'm not sure. Tell me what I got wrong.

If the folders are empty, say so and move on. Do not pretend to have read something.

**A4. What I can reach.** *"Can I see your email, calendar, or Teams from here, or will you be dropping things in?"* Check what connectors Codex on this machine has. Record the answer at the top of each page in `02-wiki/tools/`. Read-only either way.

**A5. Where things live and the play-it-safe rule.**

> Everything lives in this folder, on this machine, in this OneDrive. I draft, you send. Until we've had a second, shorter conversation about what stays private, I'll ask before I use anything about money, individual people's performance, or family. Anything you'd rather I never touch, say so now or any time, and it becomes a rule.

Anything named goes into `01-profile/boundaries.md` on the spot.

## Stage B: the interview (about 25 minutes, sixteen questions, five chunks)

**B1. Who you are** → `about-me.md`, `how-i-work.md`

1. *"If you met someone at a barbecue and they asked what you do, what would you say?"*
2. *"How did you end up doing this?"*
3. *"Think about last week. Which day went well, and what made it a good day?"*
4. *"When I bring you something, do you want the short answer, or the short answer and then the reasoning?"*

**B2. What's on** → `about-me.md`, `02-wiki/projects/`

5. *"What do people come to you for, in practice?"*
6. *"Tell me about the last thing you finished. Start to end."*
7. *"What's on right now?"* Each thing named gets a project page stub, `status: active`, one line of "where it is up to".
8. *"What's the thing that keeps not getting done?"*

Offer a break.

**B3. The people** → `02-wiki/people/`

9. *"Who are the eight or ten people you deal with most? Names and what they are to you."* A page from the template for each; every name into `aliases.md`.
10. *"For each of those: when they tell you something, how much does it move you? High, medium, or low."* `weight:` from their answer, never inferred. Hesitation: `medium`, marked `(to confirm)`.
11. *"Anyone whose word you weigh differently depending on the topic?"* One probe; onto the page under **How we work together**.

**B4. How you sound** → `my-voice.md`

12. *"Find the last three ordinary messages you wrote to people you work with: one down, one across, one up. Paste them in."*
13. *"Reading those back, anything in there that isn't quite you?"*
14. *"Any words or phrases you'd never use?"*

**B5. How we work together** → `how-i-work.md`, `boundaries.md`

15. *"What does your world call the things you work on? Programs? Workstreams? Matters?"* Relabel the projects section in the Wiki map and its README to their noun; the folder name stays.
16. *"What's in your week I should never book over or interrupt?"* The logistical slice of boundaries. The private slice is not asked today.

## Stage C: the close (about 7 minutes)

1. **Read the profile back**, all four pages, as sentences. *"What's wrong, and what's missing?"*
2. **Expectations, including a limit.** One thing you will do tomorrow (the first brief) and one you cannot (know anything you were not given).
3. **The three rituals.** Explain them in three sentences and the words that start each. Then open `_engine-room/routines.md` and walk {{OWNER_NAME}} through creating the three scheduled tasks, one at a time, reading each recipe aloud. If they would rather not schedule yet, say the rituals work by name, and note it in the Handover.
4. **Book the private conversation.** *"There's a second, shorter conversation, about what stays private and how I handle people and money. Twenty minutes, when you've got a quiet slot. Say 'just us'."*
5. **Finish.** Set `status: active` and `updated:` on all four `01-profile/` pages. Update the Wiki map. Write the note `04-sources/ingested/YYYY-MM-DD-onboarding.md`. Write the Handover, naming the private conversation as pending. Log it. Set this file's `status:` to `done`.

## When it goes sideways

| What happens | What you do |
|---|---|
| Thin answers, two in a row | Stop probing. "Tell me about the last time that happened." Still thin: move on and say the debriefs will fill it in. |
| A long tangent | Let it run. File it to the Wiki, not the profile; "back to where we were." |
| A clearly polite answer | Do not push. Carry it to the private conversation. |
| "What else can you do?" | One concrete thing tied to their answer to question 8. Never a list. |
| Past 45 minutes | Stop. Write what exists. Carry the rest. |
