---
name: decision-check
description: Pressure-test one decision before it is committed. Use when the owner says "pressure-test this", "should we do X or Y", "check this call", "what are we trading", or "are we rushing this", or is about to commit to a call worth slowing down. Five questions on one decision, fast enough to run in the moment. Never makes the decision.
---

# Decision check

**The job:** catch the shortcut before it is locked in. Five questions applied to one decision, in the minute before someone commits. Not an options paper.

The pull toward the fast answer is strongest exactly when a call is expensive, and it is invisible from inside the decision.

## Before the questions

Read the project page the decision sits on, the pages of the people whose input is in play (and their `weight:`), and the decision log for anything earlier that this call would reverse. If the decision is not on any page, say so; it may be the first thing to write down.

## The five questions

1. **Name the incentive.** What is pulling toward the fast answer? Speed, relief, looking decisive, sunk cost, someone waiting, a deadline, the option that is easiest to explain upward. Say it out loud; an unnamed incentive is the one that wins.
2. **State the fast choice plainly.** What would be chosen if nobody stopped? It cannot be examined while it is still implicit.
3. **What is being traded?** Name the cost the fast choice hides. If nothing is being traded, this is not a decision; it is a task.
4. **Reversibility.** One-way door or two-way door? Two-way doors deserve less agonising; one-way doors deserve the slow pass. Getting this backwards fails in both directions: labouring a reversible call, and sleepwalking an irreversible one.
5. **What is it optimising for**, and is that the thing that matters here? Speed, cost, reversibility, learning, someone's comfort, or the relationship with the person who asked are all legitimate answers; usually only one is true, and it is worth saying which.

## How to land it

- Surface the real trade and the one or two options that genuinely differ. Two real options beat five padded ones.
- **Do not make the decision.** Sharpen it so {{OWNER_NAME}} can. When a recommendation is worth giving, label it as one.
- When it is cheap and reversible, say so and say move. Running the full check on a trivial call spends the attention this skill exists to protect.
- If a person's stated position bears on the call, quote it from their page with the date; do not paraphrase from memory.

## Afterwards

Once {{OWNER_NAME}} decides: one line in the decision log, a dated line on the project page, and the trade named alongside it so the next reader knows what was given up. Log the run.

## Never

- Never records a decision that has not been made.
- Never lets an inferred position on a person page count as their stated one.
