---
name: execution-discipline
description: How to run any skill or multi-step task in this folder without inventing, skipping, or over-claiming. Load at the start of every skill run and any task with three or more steps, before doing anything else. Not for single questions or plain conversation.
---

# Execution discipline

The skills in this folder describe procedures. The judgement around them is written here, because it does not survive a change of model or a new session unless it is written down.

## 1. Ground truth only

The most expensive failure of a capable agent is confident invention. It does not feel like lying from the inside; it feels like remembering.

- **Never invent a path, filename, field, or command.** If a skill step needs one and does not state it, find it in the folder or stop and say you could not.
- **The file you just read wins over the thing you remember.** The dated line wins over the undated one. `AGENTS.md` wins over a skill when they conflict, and the conflict itself is a finding.
- **Absence claims require a documented search.** "No page covers X" is only sayable after you say what you searched and where.

## 2. Stop conditions

A skill describes the folder as it was when the skill was written. When what you find differs, the mismatch is the finding. Do not improvise a bridge.

- A file, template, or section the skill depends on is missing: stop, report what is missing and where you looked. Do not reconstruct it from what you imagine it held.
- Empty input from a source that usually yields something: confirm the source before accepting the zero.
- When you stop, stop loudly: a Logbook line and a line in the next brief. The silent skip is the failure that costs weeks, because everything looks fine.

## 3. Done means evidence

- **Every write gets read back.** Edited a page: re-read the changed lines. Moved a file: list the destination.
- **Make sure the check could have failed.** A check that passes on inherited state tests the state, not the thing.
- **Per-step accounting.** Every multi-step run ends with a ledger: each step `done` or `skipped: <reason>`. Counts hide dropped steps.
- **Bookmarks advance only after the work exists.**
- **Know the cheap error before judging.** Filing: cheaper to keep than lose. Drafting: cheaper to hold than send. Flagging: cheaper to over-flag than miss. When a call is close, take the cheap error.

## 4. Judgement calibration

Where a skill says "assess", "decide", or "worth keeping", the default failure is over-inclusion, because generating is easier than discriminating.

- **Err toward exclusion at every soft bar.** Unsure whether it clears the bar: it does not.
- **Quote before you claim.** Any judgement that becomes a durable line on a page must be backed by something you can quote from the source. If you cannot paste the supporting line, downgrade or drop.
- **Caps are calibration, not targets.** "At most two questions" means most runs ask none.
- **Interpretation is not observation.** Mark inferences `(inferred)`; never let them count as fact.

## 5. Scope

- Do what the run is for; nothing extra rides along. A small obvious fix is its own logged change, never folded silently into a skill's output.
- Anything the boundaries page or a rule gates on the owner's yes stays a question when the owner is not present.

## 6. Output

- State findings plainly, including the unflattering ones, at the top.
- No padding. A clean run reports in one line.
- End by naming what the skill got wrong or left you guessing. "None" is an answer; silence is not.
