---
name: enrich
description: Deepen and connect existing pages using what the working memory already holds. Use when the owner says "enrich", "enrich [page]", "deepen", or "enrich my profile". Runs on ask, or on a schedule if wanted. Fills thin sections from the notes that cite a page, adds the links that are missing, surfaces resolved threads, and proposes profile updates. Adds and connects; never rewrites existing prose.
---

# Enrich

**The job:** make the pages that matter most as complete as the notes already allow.

**Add and connect, never rewrite.** Existing sentences are fixed; enrich works around them. Ingest brings material in; lint checks structure; discover finds parallels; enrich circulates what is already inside.

## Steps

1. **Pick targets.** Named page: that page and its neighbours. Otherwise up to three: person or project pages that are `active`, cited by many notes, and thin (short, or `updated:` older than the newest note that names them). Say which you picked and why before starting.
2. **Fan out.** For each target, read every note in `04-sources/ingested/` that names it, every page that links to it, and anything in `03-working-files/` about it.
3. **Find the gaps.** Facts in the notes that the page does not carry. Sections still holding their template placeholder. An **Open between us** item the notes show was closed. Links to pages that mention the target but are not linked from it. Two notes that disagree with the page (record as a conflict, do not resolve).
4. **Apply, per page.** Add the missing facts as dated lines, each cited to its note. Fill a placeholder section only from cited material. Mark a closed item closed with the date. Add the links both ways. Bump `updated:`.
5. **Profile drift.** Only when {{OWNER_NAME}} asks for it ("enrich my profile"): compare the four `01-profile/` pages against the month's notes. Propose each change as one sentence in the report; apply on yes. Never/always lines do not wait for this; they were captured when said.
6. **Report and log.** Per page: what was added, what was linked, what conflicts were recorded, what was proposed. Logbook entry with counts.

## Never

- Never rephrases, restructures, or removes existing content.
- Never adds a fact without a note to cite.
- Never touches `01-profile/` uninvited; a proposal in the report is the ceiling.
- Never enriches a page the boundaries page puts in drawer two into anything shareable.
