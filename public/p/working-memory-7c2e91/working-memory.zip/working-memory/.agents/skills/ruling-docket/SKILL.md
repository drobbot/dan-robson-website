---
name: ruling-docket
description: Build a docket of every decision waiting on the owner, so a pile of open calls becomes one sitting. Use when the owner says "what needs my ruling", "docket", "what's waiting on me", or "batch of decisions", or when the open questions folder has grown past a handful. Each matter shows the question, the options with their trade-offs, a recommendation, and what else is theirs to call. Never decides anything.
---

# Ruling docket

**The job:** turn the pile of things waiting on {{OWNER_NAME}} into one document they can rule through in a sitting. The deliverable is "here is what needs your call", not "here is what I did".

Not for a single decision; that is a message, or a decision-check. Not for a status report with no decisions in it; that is the morning brief.

## Where the matters come from

1. `00-drop-zone/questions/` with `status: open`.
2. **Open between us** items on person pages where the ball is with {{OWNER_NAME}}.
3. **Waiting on** lines on project pages naming {{OWNER_NAME}}.
4. Anything the last three Handovers carried forward under **Open questions**.

Dedupe: one matter per decision, however many places it appears. Order by what is blocking the most, then by age.

## The docket, per matter

1. **The question**, written as a real question in plain language.
2. **Why now**: what is blocked, who is waiting, since when. One line.
3. **The options**, each with a trade-off stated in the same terms. Two real options beat five padded ones. Reference states that are not candidates are marked as such.
4. **What I'd do**: the recommendation, set apart, two short paragraphs at most: the pick and why, then what to rule out on sight.
5. **Also yours to call**: the calls that are not the option pick. A premise in the question that looks wrong, a person whose position was inferred rather than stated, anything unverified. This section is where the value usually is.
6. **Your ruling**: a blank line for the call and a line for notes.

A masthead at the top with the count and what is blocked. Written to `03-working-files/dockets/YYYY-MM-DD-docket.md`.

## Principles

- **Compare on equal footing.** Selling the pick and only costing the others is steering.
- **Keep the recommendation separate from the evidence**, so {{OWNER_NAME}} can disagree without re-reading.
- **Name what you could not verify**, in place, next to the thing.
- **Unruled is a valid outcome.** A partial pass is safe; the rest stays open.

## Afterwards

When {{OWNER_NAME}} rules, they say so in the chat or write in the docket. For each ruling: the question file flips to `answered` with the answer folded into the pages it blocked, one line in the decision log, a dated line on the project page. Hold an entry rather than record a wrong one: if a ruling contradicts the question's own premise, ask, then record. Log the run.
