---
name: ingest
description: File everything new into the Wiki. Use when the owner says "ingest", "file the drops", or "process the inbox", and at the start of start-the-day and end-of-day. Reads the Drop Zone and any connected email, Teams or calendar since the last run, vets each item against the pages it touches, writes source notes with lineage, updates the Wiki map and cross-links. Never deletes; never resolves a conflict between people.
---

# Ingest

**The job:** everything that arrived since the last run is read, vetted, filed to the pages it belongs to, and traceable to a note.

## Steps

1. **Gather.** Every file in `00-drop-zone/drops/`, and if a connector is on (see `02-wiki/tools/`), every email thread, Teams thread and calendar change since the bookmark in the last Logbook `ingest` line. Read-only on connectors.
2. **Credential check** on each item before anything else (`_engine-room/rules/filing.md` step 2).
3. **File each item** per the pipeline in `_engine-room/rules/filing.md`: identify, vet against existing pages, weigh, distribute, write the note in `04-sources/ingested/`, move the original to `04-sources/originals/`.
4. **Cross-link what you touched.** Every page written tonight links to the pages it obviously relates to (the person to the project, the decision to both), and they link back. Filing time is linking time.
5. **Update the Wiki map** for any page created. Append only.
6. **Move the bookmark** for each connector only after the writes are verified on disk. A bookmark that moves before the write is how a lost item hides forever.
7. **Log it**: one line per item filed, one per item cleared as ephemeral, the new bookmark, and `skipped: <reason>` for anything that could not be read.

## Rules

- **When unsure, file it.** Keeping too much is the cheap error.
- **Update the page that exists.** Check the Wiki map and `_engine-room/aliases.md` before creating anything.
- **Never invent structure.** No new folders. Something with no home becomes a question in `00-drop-zone/questions/`.
- **Stop loudly.** An item that could not be filed is a Logbook line and a line in the next brief, never a silent skip.
