---
name: write-it-up
description: Turn what the working memory knows about a topic into a standalone document the owner can hand to someone. Use when the owner says "write this up", "write this up properly", "turn this into something I can send", "draft a brief on", "build me a one-pager on", or "package this". Output lands in Working Files, in the owner's voice, standalone. Not a Wiki page and not a message.
---

# Write it up

**The job:** a polished, standalone document built from what the pages and notes already hold, in {{OWNER_NAME}}'s voice, for a named reader.

**What it is:** a briefing note for a board, a decision paper, a one-pager for a GM, an explainer for a new team member, a scope statement. Something that gets handed to someone and read without the folder behind it.

**What it is not:** a Wiki page (that is the Wiki), a message (that is draft-a-message), or a summary of a meeting (that is a note).

## Steps

1. **Clarify the brief, briefly.** Two questions at most, skipped if the ask already answers them: what is it for, and who reads it. Those two set the register, the depth, and the shape. If {{OWNER_NAME}} says "just write it", default to: internal, reader is their manager or the program board, scope as asked.
2. **Gather.** The project page, the people on it, the decision log lines that touch it, the notes that cite it, anything in `03-working-files/` on the topic. Read `01-profile/my-voice.md` every time.
3. **Synthesise, do not summarise.** The document stands alone. It makes an argument or states a position, {{OWNER_NAME}}'s. It connects what the pages hold separately. Every fact in it traces to a page or a note; nothing is invented to fill a gap, and a gap is named as one.
4. **Shape it to its job.** Briefing doc: context, decision needed, options, recommendation, open questions. One-pager: top line, three to five supporting points, what it asks of the reader. Explainer: the problem in the reader's words, the approach, what happens next. Let the content pick the shape.
5. **Write in their voice.** Follow `my-voice.md`: the samples, the register for that reader, the Never list. No filler, no signposting, no buzzwords. Plain.
6. **Check the boundaries page.** Nothing from drawer two. Anything from drawer three: ask first.
7. **Save** to `03-working-files/documents/YYYY-MM-DD-<slug>.md`, with a one-line pointer on the project page. Read it back once, as the reader would. Log it.

## Quality bar

- Could the reader understand it without the folder? If not, it is not standalone.
- Does every sentence earn its place?
- Is there a clear position, not a neutral dump?
- Is every fact traceable? Name in the chat what you could not source.

## Never

- Never fabricates a number, a date, or a quote. A missing fact is a bracketed gap for {{OWNER_NAME}} to fill.
- Never sends. The document sits in Working Files until {{OWNER_NAME}} moves it.
