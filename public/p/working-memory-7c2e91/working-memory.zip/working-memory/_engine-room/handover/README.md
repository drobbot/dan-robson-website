# Handover

The note each session leaves for the next, so tomorrow starts where today stopped. Three rules:

1. **One live Handover at a time**: `handover.md` in this folder. Pickup means reading exactly one note.
2. **A Handover is a baton, not an archive.** Once read, anything durable is promoted to the Wiki page it belongs to. End of day copies the outgoing note to `archive/YYYY-MM-DD.md` before writing the new one.
3. **Verify before acting.** What was true when the note was written may not be true at pickup.
