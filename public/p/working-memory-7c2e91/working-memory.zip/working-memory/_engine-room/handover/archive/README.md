Spent Handovers, one per day, `YYYY-MM-DD.md`. History only, never pickup.
