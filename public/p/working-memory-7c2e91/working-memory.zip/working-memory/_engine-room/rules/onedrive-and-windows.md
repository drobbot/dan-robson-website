# OneDrive and Windows: the environment's traps

This folder lives in a OneDrive-synced directory on a managed Windows machine, with Codex as the only agent and no git.

- **Files On-Demand.** OneDrive may show a file that is not on disk. If a read returns empty or fails, the file is probably a cloud placeholder: ask {{OWNER_NAME}} to right-click the folder and choose *Always keep on this device*. Do not conclude the file is empty.
- **Conflict copies.** A file named `<name>-<MACHINE>.md` or containing `(conflicted copy)` means OneDrive saw two writers. Never merge silently: raise a question listing both versions' `updated:` lines and let {{OWNER_NAME}} pick. Never delete either.
- **Locked files.** Windows refuses to move or overwrite a file another program has open. If a move fails, log it as `skipped: locked` and retry next session; do not copy-and-leave-the-original.
- **Folder moves.** Moving a folder inside OneDrive can produce a merged folder with both old and new contents. Never rename or move a folder inside the working memory. Files move one at a time.
- **No git means no undo.** Before substantially rewriting a page, copy the text it replaces into the note's `## Previous version` section. The Wiki map and the Logbook are append-only for the same reason.
- **Filenames.** Lowercase, hyphens, ASCII. No spaces, no `:`, `?`, `*`, `<`, `>`, `|`, no trailing dots or spaces. Keep paths short; deep paths under OneDrive hit Windows' length limit.
- **Encoding.** UTF-8 without a byte-order mark. If a page shows `Ã©`-style garbage, fix the encoding; do not "correct" the characters by hand.
- **One machine at a time.** If the folder is opened from a second device, wait for OneDrive to finish syncing first. If `handover.md` is older than the newest Logbook entry, sync has not caught up.
- **Scheduled tasks** are outside this folder and run on this machine; the caveat is in `_engine-room/routines.md`.
