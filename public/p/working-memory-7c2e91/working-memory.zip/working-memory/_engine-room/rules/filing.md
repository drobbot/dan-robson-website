# Filing: the pipeline, the note shape, and the page conventions

## The pipeline

For every item in `00-drop-zone/drops/`, and for what a connector returned, in this order:

1. **Identify.** What is it, who produced it, when? If unclear, ask before processing; do not guess a date or a speaker.
2. **Credential check.** If it contains a password, key, or login, stop: tell {{OWNER_NAME}} it happened (naming what it is for, never the value), do not file it, and recommend they delete the source. Ordinary prose containing the word "password" is not a credential.
3. **Vet** every factual claim against the pages it touches. Agrees: add the drop as a corroborating source. Extends: update the page, cite the drop, bump `updated:`. Conflicts: do not overwrite; newer does not win. Add an `## Open conflicts` section to the page (create it when the first conflict appears) and raise `00-drop-zone/questions/q-<slug>.md`. Only {{OWNER_NAME}} resolves conflicts between named people.
4. **Weigh.** When two people's inputs collide, the person pages' `weight:` lines decide the default reading, and the collision is still written down.
5. **Distribute** the vetted facts to every page they reach, and link what you touch: the person to the project, the decision to both.
6. **Write the note** at `04-sources/ingested/YYYY-MM-DD-<slug>.md` (shape below).
7. **File the original** untouched to `04-sources/originals/YYYY-MM-DD-<slug>/`. A debrief or a connector read has no original; the note is the record.
8. **Update the Wiki map** for any page created. Append; never rewrite the file.
9. **Log** one line per item in this month's Logbook file.

When unsure whether something matters, file it. The cheap error is keeping too much.

## The note shape

```
---
source: end-of-day debrief | teams thread | email | calendar | dictated note | document
date: YYYY-MM-DD
people: [../../02-wiki/people/jane-bushby.md]
raw_path: 04-sources/originals/YYYY-MM-DD-<slug>/   (or: none)
---
# Title
(What was said or found, synthesised. Never a transcript. Inferences marked (inferred).)
## What changed where
- 02-wiki/people/jane-bushby.md: added the 8 Sep steer on scope
## Previous version
(When a page was substantially rewritten because of this note, the text it replaced goes here. This is the undo; there is no git.)
```

## Page conventions

- Frontmatter on every content page in `01-profile/` and `02-wiki/people/` and `02-wiki/projects/`: `title`, `updated`, `sources`, and `status` where the page has a lifecycle (profile pages, projects). Person pages add `aliases`, `relationship`, `weight`. Section READMEs, the Wiki map, and the decision log are not content pages.
- The page answers "where is this up to?" in its first section. History goes below, dated, newest at the bottom.
- Mark inferences on the line: `(inferred)`.
- Supersession, never deletion. A replaced page gets `status: superseded` and a pointer to its successor.
- Standard relative Markdown links. Lowercase-hyphen ASCII filenames, no spaces, no trailing dots (Windows refuses them). Platform names (`AGENTS.md`, `CLAUDE.md`, `SKILL.md`, `README.md`) are exempt.
- Never invent structure. File into the folders and page kinds that exist. If something has no home, raise a question rather than creating a folder.
