# The Rules shelf

Detail that outgrew `AGENTS.md`, one topic per file, read when the topic comes up. Rules never migrate into the Wiki: the Wiki is what {{OWNER_NAME}} knows, these files are how the agent behaves.

- [filing.md](filing.md): the pipeline for a drop, the note shape, and the page conventions
- [onedrive-and-windows.md](onedrive-and-windows.md): the traps of the environment this folder lives in

---

Built by Dan Robson, Robson Studio. https://robson.studio
