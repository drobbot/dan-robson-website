# Logbook

What the agent did, so trust never rests on memory. One file per month (`2026-09.md`, `2026-10.md`), entries appended at the bottom, never inserted or rewritten. Every skill run writes one entry with a line per step: `done`, or `skipped: <reason>`. Totals alone are not a ledger.

```
## 2026-09-08 16:40 end of day
- drops filed: 2 (2026-09-08-teams-thread-jane, 2026-09-08-voice-note)
- pages updated: people/jane-bushby, projects/program-alpha, decisions/decision-log
- questions raised: q-scope-owner-alpha
- handover: written, previous archived
- skipped: none
```
