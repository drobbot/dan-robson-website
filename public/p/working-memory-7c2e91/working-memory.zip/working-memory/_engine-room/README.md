# The engine room

The plumbing. {{OWNER_NAME}} is told it exists and only opens the Logbook, when they wonder "did it write that down?".

- [rules](rules/README.md): the Rules shelf, detail that outgrew `AGENTS.md`
- [routines.md](routines.md): the three scheduled-task recipes and their one caveat
- [handover](handover/README.md): the one live note each session leaves for the next
- [logbook](logbook/README.md): the receipts, one file per month
- [aliases.md](aliases.md): one person, one page, every spelling seen

Skills live at [`.agents/skills/`](../.agents/skills/README.md), where Codex looks for them.

---

Built by Dan Robson, Robson Studio. https://robson.studio
