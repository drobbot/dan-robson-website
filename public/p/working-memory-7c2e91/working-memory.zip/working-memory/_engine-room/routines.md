# Routines: the three rituals on a schedule

A routine is a skill on a schedule. Any skill can be one; these three are the usual set. The skills live in `.agents/skills/`; the schedule lives outside this folder, as a scheduled task in ChatGPT or the Codex app (the desktop app, whichever your install shows under **Scheduled** or **Automations**; the CLI and the IDE extension cannot create one). A scheduled task is not a file, so this page ships the recipes, and {{OWNER_NAME}} creates the tasks. Onboarding walks through it.

**The one caveat, stated once.** A task that reads local files runs on this machine and needs the computer on and the app running. If a run is missed, say the words; every ritual works by name.

Two rules: run in this folder, never a worktree (there is no git here); and never two at once, so space the times.

## Start the day

- **When:** weekdays, before {{OWNER_NAME}} sits down (07:30 is the usual).
- **Prompt:** Read AGENTS.md, then run the start-the-day skill. This session was opened by a scheduled task: do not wait for input, leave the brief as your last message, and mark the Logbook line scheduled.

## End of day

- **When:** weekdays, half an hour before {{OWNER_NAME}} usually stops (16:30 is the usual).
- **Prompt:** Read AGENTS.md, then run the end-of-day skill. This session was opened by a scheduled task: file the drops, then post one line offering the debrief and wait. If no reply comes, log it and stop.

## Weekly lint

- **When:** Friday, after the end-of-day slot (17:30 is the usual; if that clashes, move it later).
- **Prompt:** Read AGENTS.md, then run the lint skill. This session was opened by a scheduled task: run everything unattended, put any questions in the Drop Zone as files and in your last message, and mark the Logbook line scheduled.

## Checking they ran

Logbook lines say `scheduled` when the schedule ran them. Two Fridays without a scheduled lint means the task is missing or the app was closed; lint says so in one line and stops there. If a recipe here changes, update the task in the app in the same session.
