# Alias table

Names drift across dictation and transcripts. One person, one page. Check here before creating a people page; add every new spelling here, never a duplicate page.

| Canonical | Aliases seen | Page |
|---|---|---|
| {{OWNER_NAME}} | (how you refer to yourself, initials) | 01-profile/about-me.md |
| Jane Bushby (example) | Jane, JB | 02-wiki/people/example-jane-bushby.md |
