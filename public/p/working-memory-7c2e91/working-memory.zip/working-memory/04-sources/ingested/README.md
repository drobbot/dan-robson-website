One distilled note per drop or debrief, `YYYY-MM-DD-<slug>.md`. Shape in `_engine-room/rules/filing.md`.
