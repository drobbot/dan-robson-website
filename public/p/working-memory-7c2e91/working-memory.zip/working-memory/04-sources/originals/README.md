Untouched originals, moved here after filing, in dated folders. Never edited.
