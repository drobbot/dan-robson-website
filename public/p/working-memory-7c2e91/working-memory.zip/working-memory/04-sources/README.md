# Sources

The lineage layer. Every fact on a Wiki page points at a note in `ingested/`, and every note points at an original in `originals/`, except a debrief, which has no original; the note is the record. The note shape is in `_engine-room/rules/filing.md`; [2026-09-08-example-end-of-day](ingested/2026-09-08-example-end-of-day.md) is a filled example.
